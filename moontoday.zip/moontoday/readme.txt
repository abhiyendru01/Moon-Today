project :moon today
The website is designed to display information about today's moon phase. It utilizes HTML, CSS, and JavaScript 
to present the current moon phase, its illumination percentage, and a corresponding moon icon. 
made by rahul(https://github.com/abhiyendru01)
check out my poortfolio:-(https://abhiyendru.netlify.app)

